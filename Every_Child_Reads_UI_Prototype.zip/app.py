"""
Every Child Reads – Telugu AI Reading Assessment Platform
Department of School Education, Government of Andhra Pradesh
Main Application Entry Point
"""
import sys
import streamlit as st

# Set page config as the very first Streamlit call
st.set_page_config(
    page_title="Every Child Reads | ప్రతి బిడ్డా చదవాలి",
    page_icon="📖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Import the core assessment app implementation
from telugu_reading_app import render_main_app

if __name__ == "__main__":
    render_main_app()

